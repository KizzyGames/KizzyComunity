# Find out the number with javascript
- ✅ Shows the `amount of errors`
- ✅ Show messages if number to find is larger or smaller
